
def dec_to_bin(n):
    result = ''
    i = 0
    while n != 0:
        n == n // 2
        print(n)



    


            

# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    print(dec_to_bin(10))
    # => '1010'
    print(dec_to_bin(5))
    # => '101'
    print(dec_to_bin(50))
    # => '110010'
